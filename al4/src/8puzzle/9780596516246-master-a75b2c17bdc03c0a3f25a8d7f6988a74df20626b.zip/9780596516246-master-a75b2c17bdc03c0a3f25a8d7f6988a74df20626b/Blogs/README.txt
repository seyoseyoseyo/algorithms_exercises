This directory contains additional source code associated
with the Monthly columns written by the authors of 
"Algorithms in a Nutshell".

Date            Contents
=============   ========================================
November_2008   Welcome to Algorithms in a Nutshell
December_2008   Searching Algorithms
January_2009    Algorithm to Solve FreeCell Solitaire Games
February_2009	Improving Performance Of Algorithms
March_2009      Network Flow Algorithms
April_2009      Computational Geometry
May_2009        Multi-threaded Algorithms


