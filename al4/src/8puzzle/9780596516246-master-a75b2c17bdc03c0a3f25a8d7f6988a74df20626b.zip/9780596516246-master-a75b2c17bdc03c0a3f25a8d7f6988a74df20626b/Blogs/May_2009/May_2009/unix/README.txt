Once you download this month's code, you will need to modify the Makefile
to properly set ADK_ROOT to the directory where you have installed the
ADK. To run the trials in trials.sh you will need to also set the ADK_ROOT
appropriately.

Instructions for installing the ADK can be found in the ZIP file

  http://examples.oreilly.com/9780596516246/Releases/

Once you edit the Makefile accordingly, type 'make' to build the
multi-thread quicksort code.
