package algs.model.tests.common;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Scanner;
import java.util.StringTokenizer;


public class TrialSuiteHelper {

	/**
	 * Combine the set of trials (which all must use the same number of rows) into 
	 * a single table that only shows the average results.
	 * 
	 * @param trials
	 * @return
	 */
	public static String combine(TrialSuite[] trials) {
		if (trials == null || trials.length == 0) { return ""; }
		if (trials.length == 1) { return trials[0].computeTable(); }
		
		boolean extractHeader = true;
			
		// compute headers.
		Hashtable<String,String> results = new Hashtable<String,String>();
		ArrayList<String> order = new ArrayList<String>();
		for (int t = 0; t < trials.length; t++) {
			// last one always
			Scanner sc = new Scanner (trials[t].computeTable());
			sc.nextLine(); // skip header
			while (sc.hasNextLine()) {
				StringTokenizer st = new StringTokenizer(sc.nextLine(), ",");
				String ct = st.nextToken(); // extract if required
				String avg = st.nextToken();
				
				if (extractHeader) {
					order.add(ct);
					results.put(ct, avg);
				} else {
					String s = results.get(ct);
					s += "," + avg;
					results.put (ct, s);
				}
			}
			
			extractHeader = false; // done
		}
		
		// combine
		String retValue = "";
		for (String s : order) {
			retValue += s + "," + results.get(s) + "\n";
		}
		
		return retValue;
	}
}
