Welcome to the Code Repository associated with the "Algorithms in a Nutshell"
book. Here you will find:

  README.txt            This File
  Blogs                 Code associated with monthly blog columns
  ExtendedFigures       Larger versions of Figures in Book 
  Releases              Releases of the Algorithm Development Kit
