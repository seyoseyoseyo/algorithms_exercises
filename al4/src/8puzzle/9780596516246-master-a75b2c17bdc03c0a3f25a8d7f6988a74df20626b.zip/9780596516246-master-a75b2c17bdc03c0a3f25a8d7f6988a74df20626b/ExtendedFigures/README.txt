This directory contains images that were simply too large to include as
figures in the book. In many cases, these are the original images which
were subsequently shrunk to be able to fit within the 4" x 6" limitation of
the book format. Other images are just interesting images that were
generated as part of this project, yet couldn't find a way into the book.

Each DOT file contains layout commands that the Graphviz dot software
(http://www.graphviz.org) converts into Postscript output. We used Adobe
Distiller to produce the enclosed PDF documents.

Enjoy!

George T. Heineman
Gary Pollice
Stanley Selkow


Index of Files
==============

  BadEvaluator.dot 
  BadEvaluator.pdf

     Figures 7-11 and 7-12 present two A*Search search trees using the
     GoodEvaluator and the WeakEvaluator heuristic functions. There is
     another heuristic which we called BadEvaluator because it is truly
     awful. The resulting tree searches over 7000 nodes and discovers a
     solution of 127 moves. This image contains the search tree produced by
     A*Search.

  7-13.dot
  7-13.pdf

     Sample 15-puzzle is a bit compressed in the book. This PDF contains
     the image in its original size.

  7-17.dot
  7-17.pdf

     Sample Minimax 2-ply exploration for a tic-tac-toe board. This
     original figure was too big and was abstractly redrawn to fit.

  7-19.dot
  7-19.pdf

     Sample NegMax 2-ply exploration for a tic-tac-toe board. This
     original figure was too big and was abstractly redrawn to fit. Note
     that we use "INF" and "-INF" to represent positive and negative
     infinity in these automatically generated images. The book artists
     were able to replace these with the appropriate greek symbols.

  7-21.dot
  7-21.pdf

     Sample AlphaBeta 2-ply exploration for a tic-tac-toe board. This
     original figure was too big and was abstractly redrawn to fit.

  7-22.dot
  7-22.pdf

     Sample AlphaBeta 3-ply exploration for a tic-tac-toe board. This
     original figure was too big and was abstractly redrawn to fit.

  7-22a.dot
  7-22a.pdf

     This image was not included in the book. This reproduces the full
     Minimax search tree that corresponds to the reduced AlphaBeta search
     tree as depicted in 7-22.pdf above.
